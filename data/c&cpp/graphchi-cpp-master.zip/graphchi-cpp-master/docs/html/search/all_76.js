var searchData=
[
  ['variable_5fis_5fnot_5fused',['VARIABLE_IS_NOT_USED',['../graph__objects_8hpp.html#a374bd2d6076b95bff33ea625a1e25e09',1,'VARIABLE_IS_NOT_USED():&#160;graph_objects.hpp'],['../conversions_8hpp.html#a374bd2d6076b95bff33ea625a1e25e09',1,'VARIABLE_IS_NOT_USED():&#160;conversions.hpp'],['../cmdopts_8hpp.html#a374bd2d6076b95bff33ea625a1e25e09',1,'VARIABLE_IS_NOT_USED():&#160;cmdopts.hpp']]],
  ['vcallback',['VCallback',['../classgraphchi_1_1_v_callback.html',1,'graphchi']]],
  ['vcallback_3c_20latentvec_5ft_20_3e',['VCallback&lt; latentvec_t &gt;',['../classgraphchi_1_1_v_callback.html',1,'graphchi']]],
  ['vec',['vec',['../structvec.html',1,'']]],
  ['vertex_5faggregator_2ehpp',['vertex_aggregator.hpp',['../vertex__aggregator_8hpp.html',1,'']]],
  ['vertex_5fdata',['vertex_data',['../structvertex__data.html',1,'vertex_data'],['../structvertex__data.html#a7f177e8488c52777a14aef50256dd489',1,'vertex_data::vertex_data()']]],
  ['vertex_5fdata_2ehpp',['vertex_data.hpp',['../vertex__data_8hpp.html',1,'']]],
  ['vertex_5fdata_5fstore',['vertex_data_store',['../classgraphchi_1_1vertex__data__store.html',1,'graphchi']]],
  ['vertex_5fdegree',['vertex_degree',['../structgraphchi_1_1vertex__degree.html',1,'graphchi']]],
  ['vertex_5fid',['vertex_id',['../classgraphchi_1_1graphchi__edge.html#a5d55d4d82a58faa5858dfb898f2258d6',1,'graphchi::graphchi_edge']]],
  ['vertex_5fid_5ftype',['vertex_id_type',['../classgraphlab_1_1icontext.html#a1a1817b36be531195eb5bf374cc393ce',1,'graphlab::icontext']]],
  ['vertex_5finfo',['vertex_info',['../structgraphchi_1_1vertex__info.html',1,'graphchi']]],
  ['vertex_5ftype',['vertex_type',['../classgraphlab_1_1icontext.html#a16c26ddb8bbbef6c0aa62fcbb1d8157d',1,'graphlab::icontext']]],
  ['vertex_5fvalue',['vertex_value',['../structgraphchi_1_1vertex__value.html',1,'graphchi']]],
  ['vertexdatachecker',['VertexDataChecker',['../class_vertex_data_checker.html',1,'']]],
  ['vertexdatatype',['VertexDataType',['../basic__dynamicengine__smoketest_8cpp.html#acf10237949ab87b83055ff6aa646c565',1,'VertexDataType():&#160;basic_dynamicengine_smoketest.cpp'],['../basic__dynamicengine__smoketest2_8cpp.html#acf10237949ab87b83055ff6aa646c565',1,'VertexDataType():&#160;basic_dynamicengine_smoketest2.cpp'],['../basic__smoketest_8cpp.html#acf10237949ab87b83055ff6aa646c565',1,'VertexDataType():&#160;basic_smoketest.cpp'],['../application__template_8cpp.html#ae4d85c752cba765fad928a80862556b1',1,'VertexDataType():&#160;application_template.cpp'],['../communitydetection_8cpp.html#acf10237949ab87b83055ff6aa646c565',1,'VertexDataType():&#160;communitydetection.cpp'],['../connectedcomponents_8cpp.html#acf10237949ab87b83055ff6aa646c565',1,'VertexDataType():&#160;connectedcomponents.cpp'],['../als__edgefactors_8cpp.html#acd2f11571e777894d1d2b0faab84bbb8',1,'VertexDataType():&#160;als_edgefactors.cpp'],['../als__vertices__inmem_8cpp.html#acd2f11571e777894d1d2b0faab84bbb8',1,'VertexDataType():&#160;als_vertices_inmem.cpp'],['../trianglecounting_8cpp.html#a16cfed23cb3f46f5044fc90df1a56aaf',1,'VertexDataType():&#160;trianglecounting.cpp']]]
];
