var searchData=
[
  ['xtx',['XtX',['../classgather__type.html#a79352d3ca5b6957aa4b21276c20da59f',1,'gather_type']]],
  ['xy',['Xy',['../classgather__type.html#a319a1856f1ad204ad8fd13592ab9a201',1,'gather_type']]]
];
