var searchData=
[
  ['managed_5fpwritea_5fasync',['managed_pwritea_async',['../classgraphchi_1_1stripedio.html#a8fa21b2d669bd4ae553dffe483932fa9',1,'graphchi::stripedio']]],
  ['metrics_5freport',['metrics_report',['../namespacegraphchi.html#ac96bf710c0bf6795fde16808d06aec61',1,'graphchi']]]
];
